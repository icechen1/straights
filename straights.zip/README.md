# straights
CS247 Project 1
